package com.damani.spring.service;

import com.damani.spring.model.Book;

import java.util.List;


//What is the purpose of this class? Its exactly the same BookDao. It appears in the BookController, but why can't BookServiceImpl just implement BookDao?

public interface BookService {

    //save the record
    long save(Book book);

    //get a single records
    Book get(long id);

    //get all the records
    List<Book> list();

    //update records
    void update(long id, Book book);

    void delete(long id);
}

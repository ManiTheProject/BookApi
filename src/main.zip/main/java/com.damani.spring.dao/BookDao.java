package com.damani.spring.dao;

import com.damani.spring.model.Book;

import java.util.List;

public interface BookDao {

    //save the record
    long save(Book book);

    //get a single records
    Book get(long id);

    //get all the records
    List<Book> list();

    //update records
    void update(long id, Book book);

    void delete(long id);
}
